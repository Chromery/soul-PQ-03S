const defaultQwenCaptchaEndpoint = "https://pq-soul.rainailab.com/api/qwen-captcha";
const hostedQwenCaptchaEndpoints = [
  "https://pq-soul.rainailab.com/api/qwen-captcha",
  "https://soul-pq-alpha.rainailab.com/api/qwen-captcha",
  "https://soul-pq-alpha-2.iggau.com/api/qwen-captcha"
];
const defaultSettings = {
  autoSubmitCaptchaSearch: false,
  autoSubmitDelaySeconds: 3
};

function normalizeSettings(value) {
  const delay = Number(value && value.autoSubmitDelaySeconds);

  return {
    autoSubmitCaptchaSearch: Boolean(value && value.autoSubmitCaptchaSearch),
    autoSubmitDelaySeconds: Number.isFinite(delay)
      ? Math.min(60, Math.max(0, Math.round(delay)))
      : defaultSettings.autoSubmitDelaySeconds
  };
}

async function getSettings() {
  const stored = await chrome.storage.local.get(defaultSettings);
  return normalizeSettings(stored);
}

function allowedQwenEndpoint(value) {
  if (typeof value !== "string") {
    return null;
  }

  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();
    const localHosts = new Set(["localhost", "127.0.0.1", "0.0.0.0", "[::1]"]);
    const pqHosts = new Set([
      "pq-soul.rainailab.com",
      "st-pq-soul.rainailab.com",
      "soul-pq-alpha.rainailab.com",
      "soul-pq-alpha-2.iggau.com"
    ]);
    const isLocalOrTailscale = localHosts.has(host) || isTailscaleIp(host) || host.endsWith(".ts.net");
    const isPqHosted = url.protocol === "https:" && pqHosts.has(host);
    const protocolAllowed = (url.protocol === "http:" && isLocalOrTailscale)
      || (url.protocol === "https:" && (isPqHosted || host.endsWith(".ts.net")));
    const hostAllowed = isLocalOrTailscale || isPqHosted;

    if (
      !protocolAllowed
      || !hostAllowed
      || url.pathname !== "/api/qwen-captcha"
    ) {
      return null;
    }

    return url.toString();
  } catch (error) {
    return null;
  }
}

function isTailscaleIp(host) {
  const parts = host.split(".");

  if (parts.length !== 4) {
    return false;
  }

  const octets = parts.map((part) => Number(part));

  if (octets.some((octet) => !Number.isInteger(octet) || octet < 0 || octet > 255)) {
    return false;
  }

  return octets[0] === 100 && octets[1] >= 64 && octets[1] <= 127;
}

function qwenEndpointCandidates(metadata) {
  const configured = allowedQwenEndpoint(
    metadata && metadata.options ? metadata.options.qwenCaptchaEndpoint : null
  );
  const candidates = [
    configured,
    defaultQwenCaptchaEndpoint,
    ...hostedQwenCaptchaEndpoints,
    "http://127.0.0.1:4173/api/qwen-captcha",
    "http://localhost:4173/api/qwen-captcha"
  ].filter(Boolean);

  return [...new Set(candidates)];
}

function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  return fetch(url, {
    ...options,
    signal: controller.signal
  }).finally(() => clearTimeout(timeoutId));
}

async function readResponsePayload(response) {
  const text = await response.text();

  try {
    return text ? JSON.parse(text) : null;
  } catch (error) {
    return { text };
  }
}

async function sendCaptchaToQwen(imageDataUrl, metadata) {
  if (typeof imageDataUrl !== "string" || !imageDataUrl.startsWith("data:image/")) {
    return {
      ok: false,
      skipped: true,
      error: "missing_image_data_url"
    };
  }

  const attempts = [];

  const configured = allowedQwenEndpoint(metadata?.options?.qwenCaptchaEndpoint);
  if (configured && ["https://pq-soul.rainailab.com", "https://st-pq-soul.rainailab.com"].includes(new URL(configured).origin)) {
    const origin = new URL(configured).origin;
    const tabs = await chrome.tabs.query({ url: `${origin}/*` });
    for (const tab of tabs) {
      try {
        const result = await chrome.tabs.sendMessage(tab.id, { type: "pq-authenticated-captcha", imageDataUrl });
        if (result?.ok) return { ...result, endpoint: configured };
      } catch { /* The PQ tab might need reloading after extension installation. */ }
    }
    return { ok: false, error: "Apri PQ, accedi e mantieni aperta la scheda. Ricaricala dopo aver aggiornato l’estensione." };
  }

  for (const endpoint of qwenEndpointCandidates(metadata)) {
    const startedAt = Date.now();

    try {
      const response = await fetchWithTimeout(endpoint, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-formaps-open-extension": "1"
        },
        body: JSON.stringify({ imageDataUrl })
      }, 45000);
      const payload = await readResponsePayload(response);
      const attempt = {
        endpoint,
        status: response.status,
        durationMs: Date.now() - startedAt
      };

      if (response.ok) {
        return {
          ok: true,
          ...attempt,
          response: payload
        };
      }

      return {
        ok: false,
        ...attempt,
        error: payload && payload.error ? payload.error : `http_${response.status}`,
        response: payload
      };
    } catch (error) {
      attempts.push({
        endpoint,
        durationMs: Date.now() - startedAt,
        error: error && error.name === "AbortError"
          ? "timeout"
          : error && error.message ? error.message : String(error)
      });
    }
  }

  return {
    ok: false,
    error: "qwen_proxy_unreachable",
    attempts
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.source !== "formaps-open-page") {
    return false;
  }

  if (message.type === "settings-request") {
    getSettings()
      .then((settings) => sendResponse({ ok: true, settings }))
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error && error.message ? error.message : String(error),
          settings: defaultSettings
        });
      });

    return true;
  }

  if (message.type !== "captcha-captured") {
    return false;
  }

  (async () => {
    const results = {
      qwen: null
    };
    results.qwen = await sendCaptchaToQwen(message.imageDataUrl, message.metadata);
    sendResponse({ ok: true, results });
  })().catch((error) => {
    sendResponse({
      ok: false,
      error: error && error.message ? error.message : String(error)
    });
  });

  return true;
});
